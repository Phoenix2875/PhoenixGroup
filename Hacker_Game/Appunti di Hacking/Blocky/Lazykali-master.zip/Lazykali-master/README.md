Lazykali
========

hackpack to go with lazykali on menu application Kali Linux
